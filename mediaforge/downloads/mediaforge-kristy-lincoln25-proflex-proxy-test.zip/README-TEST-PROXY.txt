MediaForge Lincoln 25 Pro Flex proxy road-test batch

These are NOT the exact Liberty Canto originals. They are public-web proxy images packaged under Kristy's six Canto-style source filenames so we can road-test MediaForge intake, parsing, interior-number inheritance, audit preview, and ZIP output before Canto access is restored.

Do not use these proxy images as production product photography.
